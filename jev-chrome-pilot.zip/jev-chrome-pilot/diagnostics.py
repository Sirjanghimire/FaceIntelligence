"""Connection-only diagnostics: no keys, page text, URLs, or protocol payloads."""

import datetime
import json
import threading
import time
from contextlib import contextmanager
from pathlib import Path

LOCK = threading.RLock()
LOG_PATH = None
HEARTBEAT_SECONDS = 5


def console(record):
    with LOCK:
        print(json.dumps(record, ensure_ascii=False), flush=True)


def initialize(directory):
    global LOG_PATH
    directory = Path(directory)
    directory.mkdir(exist_ok=True, parents=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    LOG_PATH = directory / f"connection-{stamp}.jsonl"
    return LOG_PATH


def emit(stage, state, **fields):
    if LOG_PATH is None:
        return
    record = {
        "event": "connection_debug",
        "timestamp": datetime.datetime.now().astimezone().isoformat(timespec="milliseconds"),
        "stage": stage,
        "state": state,
        **fields,
    }
    with LOCK:
        console(record)
        with LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")


def error_fields(exc):
    chain = []
    current = exc
    while current is not None and len(chain) < 5:
        chain.append(type(current).__name__)
        current = current.__cause__
    result = {"error_types": chain}
    for name in ("errno", "status_code"):
        value = getattr(exc, name, None)
        if isinstance(value, int):
            result[name] = value
    return result


@contextmanager
def stage(name, **fields):
    started = time.monotonic()
    stop = threading.Event()
    emit(name, "start", **fields)

    def heartbeat():
        while not stop.wait(HEARTBEAT_SECONDS):
            emit(name, "waiting", elapsed_s=round(time.monotonic() - started, 1), **fields)

    thread = threading.Thread(target=heartbeat, daemon=True)
    if LOG_PATH is not None:
        thread.start()
    try:
        yield
    except BaseException as exc:
        stop.set()
        if thread.is_alive():
            thread.join(timeout=1)
        emit(name, "error", elapsed_s=round(time.monotonic() - started, 2), **fields, **error_fields(exc))
        raise
    else:
        stop.set()
        if thread.is_alive():
            thread.join(timeout=1)
        emit(name, "complete", elapsed_s=round(time.monotonic() - started, 2), **fields)
