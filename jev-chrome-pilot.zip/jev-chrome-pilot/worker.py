"""Automatic planner -> Jev action loop -> final assessment, in an isolated process."""

import datetime
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import diagnostics
import services
from jev_ultrafast import Agent
from planner import assess, make_plan, observation_text, route_task

BASE = Path(__file__).resolve().parent


def validate_config(config):
    goal = config.get("goal", "").strip()
    if not 1 <= len(goal) <= 2000:
        raise ValueError("Enter a task of 1–2000 characters.")
    url = config.get("url", "").strip()
    if url:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Enter an HTTP(S) URL, or leave blank to keep the selected tab.")
    if type(config.get("steps", 40)) is not int or not 1 <= config.get("steps", 40) <= 60:
        raise ValueError("Use between 1 and 60 actions.")
    if not isinstance(config.get("expect", ""), str) or len(config.get("expect", "")) > 1000:
        raise ValueError("Expected text must have at most 1000 characters.")
    services.groq_model(config.get("model", "openai/gpt-oss-120b"))
    return {**config, "goal": goal, "url": url}


def execute_plan(agent, config, emit):
    goal = config["goal"]
    initial = agent.state["page"]
    if not config.get("plan"):
        emit({"event": "planning", "message": "GPT-OSS is planning your task."})
    plan = config.get("plan") or make_plan(goal, initial, datetime.datetime.now().astimezone().isoformat())
    emit({"event": "plan", "plan": plan})
    if plan["needs_input"]:
        emit({"event": "finished", "status": "needs_input", "message": plan["needs_input"]})
        return
    # The original goal remains authoritative. The planner offers high-level guidance,
    # not preselected targets or scripted field values.
    agent.state["goal"] = (
        goal
        + "\n\nPlanner guidance (use only if consistent with the original goal):\n"
        + json.dumps(plan, ensure_ascii=False)
    )
    emitted_actions = 0
    started = time.monotonic()
    while agent.state["status"] not in ("done", "blocked"):
        if time.monotonic() - started > 600:
            raise RuntimeError("Ten-minute execution limit reached.")
        if len(agent.state["history"]) >= config.get("steps", 40):
            raise RuntimeError("Action limit reached. Inspect the browser before restarting.")
        if len(agent.state["decisions"]) >= min(100, config.get("steps", 40) * 2 + 4):
            raise RuntimeError("Decision limit reached.")
        try:
            agent.command("tick")
        finally:
            # The foundation records actions before the next observation. Preserve that
            # evidence even when observation or navigation fails after an input.
            for action in agent.state["history"][emitted_actions:]:
                emit(
                    {
                        "event": "action",
                        **{
                            k: action.get(k)
                            for k in ("step", "action", "operation", "confidence", "probability", "text", "latency_ms")
                        },
                    }
                )
            emitted_actions = len(agent.state["history"])
            if agent.state.get("last_retry"):
                emit({"event": "action_retry", **agent.state["last_retry"]})
        if agent.state["decisions"]:
            decision = agent.state["decisions"][-1]
            emit(
                {
                    "event": "decision",
                    "operation": decision["operation"],
                    "confidence": decision["confidence"],
                    "target_confidence": decision.get("target_confidence"),
                    "status": agent.state["status"],
                }
            )
    if agent.state["status"] != "done":
        emit({"event": "finished", "status": "blocked",
              "message": agent.state.get("blocked_reason", "Jev could not continue.")})
        return
    final = agent.browser.observe(screenshot=False)
    expected = config.get("expect", "").strip()
    explicit_check = expected in observation_text(final) if expected else None
    emit(
        {
            "event": "checking",
            "expected_text_found": explicit_check,
            "message": "Checking the final page against the original goal.",
        }
    )
    if explicit_check is False:
        emit(
            {
                "event": "finished",
                "status": "verification_failed",
                "message": "Expected text was not found in the final observation.",
            }
        )
        return
    result = assess(goal, final, plan["success_criteria"])
    emit(
        {
            "event": "finished",
            "status": "model_assessed_complete" if result["satisfied"] else "verification_uncertain",
            "assessment": result,
            "expected_text_found": explicit_check,
            "message": "Model assessment plus any supplied text check; not a guarantee of full task correctness.",
        }
    )


def main():
    config = json.loads(sys.stdin.readline())
    diagnostics.initialize(BASE / "logs")
    log = BASE / "logs" / (datetime.datetime.now().strftime("run-%Y%m%d-%H%M%S-%f") + ".jsonl")

    def emit(record):
        line = json.dumps(record, ensure_ascii=False)
        for key in (os.environ.get("TYPESAFE_API_KEY", ""), os.environ.get("GROQ_API_KEY", "")):
            if key:
                line = line.replace(key, "[REDACTED]")
        with diagnostics.LOCK:
            print(line, flush=True)
            with log.open("a", encoding="utf-8") as stream:
                stream.write(line + "\n")

    services.EVENT = emit
    agent = None
    try:
        config = validate_config(config)
        if not os.environ.get("TYPESAFE_API_KEY") or not os.environ.get("GROQ_API_KEY"):
            raise ValueError("Enter both API keys.")
        os.environ["TEXT_MODEL"] = config.get("model", "openai/gpt-oss-120b")
        os.environ["JEV_CHROME_PROFILE"] = config.get("profile", "").strip()
        emit({"event": "planning", "message": "GPT-OSS is choosing the website and planning your instruction."})
        routed = route_task(config["goal"], config["url"], datetime.datetime.now().astimezone().isoformat())
        config.update(url=routed["url"], plan=routed["plan"])
        emit({"event": "plan", "url": config["url"], "plan": config["plan"]})
        if config["plan"]["needs_input"]:
            emit({"event": "finished", "status": "needs_input", "message": config["plan"]["needs_input"]})
            return 0
        emit(
            {
                "event": "connecting",
                "message": "Opening or reusing normal Chrome. Enable debugging and click Allow if Chrome asks.",
            }
        )
        agent = Agent(config["url"], config["goal"])
        emit({"event": "executing", "message": "Chrome connected. Jev is executing the planned task."})
        execute_plan(agent, config, emit)
        return 0
    except Exception as exc:
        emit({"event": "error", "message": services.clean_error(exc)})
        return 1
    finally:
        if agent:
            try:
                agent.close()
            except Exception as exc:
                emit({"event": "cleanup", "message": services.clean_error(exc)})
        emit({"event": "usage", **services.STATS})
        services.HTTP.close()


if __name__ == "__main__":
    raise SystemExit(main())
