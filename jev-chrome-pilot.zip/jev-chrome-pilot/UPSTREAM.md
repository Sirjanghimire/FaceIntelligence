# Foundation

Jev execution code derives from browser-use/jev-ultrafast commit
1231850a0bf1a0c0341fe408ef1668dbbfdfac46. Original MIT LICENSE retained.
https://github.com/browser-use/jev-ultrafast

Browser connection uses the official installed browser-harness 0.1.13 package:
https://github.com/browser-use/browser-harness

The executor retains atomic DOM snapshots, observed-node identity, action/target validation, freshness and occlusion guards, native input, and bounded decisions. The new transport uses `browser_harness.admin.ensure_daemon` and `browser_harness.helpers.cdp`.

Our Windows startup helper explicitly locates normal Google Chrome's profile and debugging metadata, then supplies that Chrome WebSocket to a dedicated Harness daemon. This avoids Harness auto-discovery accidentally attaching to an already-enabled Brave instance. It is a deliberate Chrome-only adaptation of Harness's general auto-start behavior. It never uses a temporary browser user-data directory.

The Groq GPT-OSS planner runs before opening the website, selecting URL/subgoals from the original instruction. The existing text helper and final assessment remain. The GUI uses one instruction, optional website override, and optional existing profile folder. No upstream performance or accuracy claim is made.

1.0.2 adds action-scoped fill guards, occlusion filtering, focus verification and bounded, logged stale retries.
