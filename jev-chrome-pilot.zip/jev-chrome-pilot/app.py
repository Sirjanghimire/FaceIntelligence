"""One instruction -> Groq GPT-OSS planner -> ordinary Chrome profile -> Jev."""

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

BASE = Path(__file__).resolve().parent


class App:
    def __init__(self, root):
        self.root, self.worker = root, None
        self.events = queue.Queue()
        self.stopped = False
        root.title("Jev Chrome Pilot 1.0.1 — your normal Chrome")
        root.geometry("940x700")
        root.minsize(760, 620)
        panel = ttk.Frame(root, padding=16)
        panel.pack(fill="both", expand=True)
        ttk.Label(panel, text="JEV CHROME PILOT", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(
            panel, text="Describe the task. GPT-OSS chooses the website. Jev uses your normal Chrome."
        ).pack(anchor="w", pady=6)
        row = ttk.Frame(panel)
        row.pack(fill="x")
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=1)
        ttk.Label(row, text="TypeSafe key").grid(row=0, column=0, sticky="w")
        ttk.Label(row, text="Groq API key").grid(row=0, column=1, sticky="w", padx=10)
        self.jev = ttk.Entry(row, show="*")
        self.router = ttk.Entry(row, show="*")
        self.jev.grid(row=1, column=0, sticky="ew")
        self.router.grid(row=1, column=1, sticky="ew", padx=10)
        self.jev.insert(0, os.environ.get("TYPESAFE_API_KEY", ""))
        self.router.insert(0, os.environ.get("GROQ_API_KEY", ""))
        ttk.Label(panel, text="Your instruction — include recipient, subject and message for email tasks").pack(
            anchor="w", pady=(12, 3)
        )
        self.goal = tk.Text(panel, height=4, wrap="word", font=("Segoe UI", 11))
        self.goal.pack(fill="x")
        ttk.Label(panel, text="Website (optional — leave blank for the LLM to choose)").pack(anchor="w", pady=(8, 3))
        self.url = ttk.Entry(panel)
        self.url.pack(fill="x")
        row = ttk.Frame(panel)
        row.pack(fill="x", pady=10)
        ttk.Label(row, text="Groq model").pack(side="left")
        self.model = ttk.Entry(row, width=29)
        self.model.insert(0, "openai/gpt-oss-120b")
        self.model.pack(side="left", padx=6)
        ttk.Label(row, text="Chrome profile folder (optional)").pack(side="left")
        self.profile = ttk.Entry(row, width=15)
        self.profile.pack(side="left", padx=6)
        ttk.Label(
            panel, text="Blank profile uses Chrome’s last-used profile. Example folder names: Default or Profile 1."
        ).pack(anchor="w")
        row = ttk.Frame(panel)
        row.pack(fill="x", pady=10)
        self.run = ttk.Button(row, text="Run instruction", command=self.start)
        self.run.pack(side="left")
        ttk.Button(row, text="Stop", command=self.stop).pack(side="left", padx=8)
        ttk.Button(row, text="Open logs", command=self.open_logs).pack(side="right")
        ttk.Button(row, text="Copy activity", command=self.copy_activity).pack(side="right", padx=8)
        self.status = tk.StringVar(value="Ready. Chrome can be closed; the app opens it with its existing profile.")
        ttk.Label(panel, textvariable=self.status, wraplength=880).pack(anchor="w")
        self.output = tk.Text(panel, height=12, wrap="word", state="disabled", font=("Consolas", 10))
        self.output.pack(fill="both", expand=True, pady=8)
        ttk.Label(
            panel,
            text="Automatic actions • page content goes to TypeSafe/Groq • keys are not saved",
            wraplength=850,
        ).pack(anchor="w")
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(100, self.poll)

    def append(self, text):
        self.output.configure(state="normal")
        self.output.insert("end", text + "\n")
        self.output.see("end")
        self.output.configure(state="disabled")

    def start(self):
        if self.worker and self.worker.poll() is None:
            return
        config = {
            "goal": self.goal.get("1.0", "end").strip(),
            "url": self.url.get().strip(),
            "profile": self.profile.get().strip(),
            "model": self.model.get().strip(),
            "steps": 40,
        }
        try:
            from worker import validate_config

            validate_config(config)
            if not self.jev.get().strip() or not self.router.get().strip():
                raise ValueError("Enter both API keys.")
            env = {
                **os.environ,
                "TYPESAFE_API_KEY": self.jev.get().strip(),
                "GROQ_API_KEY": self.router.get().strip(),
                "PYTHONIOENCODING": "utf-8",
            }
            self.worker = subprocess.Popen(
                [sys.executable, "-u", str(BASE / "worker.py")],
                cwd=BASE,
                env=env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            self.worker.stdin.write(json.dumps(config) + "\n")
            self.worker.stdin.flush()
            self.worker.stdin.close()
        except Exception as exc:
            messagebox.showerror("Cannot start", str(exc))
            return
        self.stopped = False
        self.run.configure(state="disabled")
        self.status.set("Planning your instruction…")
        self.append("Starting a new task…")
        worker = self.worker

        def reader():
            for line in worker.stdout:
                self.events.put((worker, line.rstrip()))
            worker.wait()
            self.events.put((worker, None))

        threading.Thread(target=reader, daemon=True).start()

    def poll(self):
        while not self.events.empty():
            worker, line = self.events.get()
            if worker is not self.worker:
                continue
            if line is None:
                self.run.configure(state="normal")
                self.append(
                    "Stopped by you." if self.stopped else f"Worker ended ({worker.returncode}); Chrome remains open."
                )
                continue
            self.append(line)
            try:
                record = json.loads(line)
            except ValueError:
                continue
            if record.get("message"):
                self.status.set(record["message"])
            elif record.get("event") == "connection_debug":
                self.status.set(f"{record['stage']}: {record['state']}")
        self.root.after(100, self.poll)

    def stop(self):
        if self.worker and self.worker.poll() is None:
            self.stopped = True
            self.worker.terminate()  # Never terminate Chrome or the Harness daemon.
            self.status.set("Stopped. Already-issued actions may finish; Chrome stays open.")

    def open_logs(self):
        folder = BASE / "logs"
        folder.mkdir(exist_ok=True)
        if os.name == "nt":
            os.startfile(folder)

    def copy_activity(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.output.get("1.0", "end"))
        self.status.set("Activity copied. It can include private task text.")

    def close(self):
        self.stop()
        self.root.destroy()


if __name__ == "__main__":
    App(tk.Tk()).root.mainloop()
