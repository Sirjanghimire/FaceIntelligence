"""Jev's CDP executor through the official Browser Harness daemon."""

import os
import time
import uuid

import diagnostics
from chrome_startup import connect_harness

_SESSIONS = {}


def cdp(method, *, session_id, **params):
    transport = _SESSIONS[session_id]
    with diagnostics.stage("cdp_request", method=method):
        return transport.call(method, session_id=transport.remote_session, _response_timeout=30, **params)


class BrowserTransport:
    def __init__(self):
        self.call = connect_harness(os.environ.get("JEV_CHROME_PROFILE", ""))
        self.session_id = uuid.uuid4().hex
        self.remote_session = None
        try:
            # A new TAB, in normal Chrome's existing context. No fresh browser/profile.
            target = self.call("Target.createTarget", url="about:blank", _response_timeout=30)["targetId"]
            self.remote_session = self.call(
                "Target.attachToTarget", targetId=target, flatten=True, _response_timeout=30
            )["sessionId"]
            _SESSIONS[self.session_id] = self
            cdp("Page.enable", session_id=self.session_id)
            cdp("Page.bringToFront", session_id=self.session_id)
        except Exception:
            self.close()
            raise

    def navigate(self, url):
        result = cdp("Page.navigate", session_id=self.session_id, url=url)
        if result.get("errorText") or result.get("isDownload"):
            raise RuntimeError("Navigation failed or became a download. Inspect Chrome before rerunning.")
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            frame = cdp("Page.getFrameTree", session_id=self.session_id)["frameTree"]["frame"]
            if result.get("loaderId") and frame.get("loaderId") != result["loaderId"]:
                time.sleep(0.1)
                continue
            state = cdp(
                "Runtime.evaluate", session_id=self.session_id, expression="document.readyState", returnByValue=True
            )
            if state.get("result", {}).get("value") in ("interactive", "complete"):
                return
            time.sleep(0.1)
        raise RuntimeError("Chrome navigation did not settle in 30 seconds.")

    def close(self):
        _SESSIONS.pop(self.session_id, None)
        if self.remote_session:
            self.call("Target.detachFromTarget", sessionId=self.remote_session, _response_timeout=5)
            self.remote_session = None
        # Harness retains the approved browser connection. Leave all Chrome tabs open.
