@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Setup complete. START.bat opens the app.
echo Uses your installed Google Chrome and existing profile. No Chromium download is needed.
exit /b 0
:fail
echo Setup failed. Install Python 3.12 from python.org including the Python launcher.
echo Check the installation error above.
pause
exit /b 1
