@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe goto setup
.venv\Scripts\python.exe -c "import browser_harness, httpx, h2" >nul 2>&1
if errorlevel 1 goto setup
goto run
:setup
call SETUP.bat
if errorlevel 1 exit /b 1
:run
.venv\Scripts\python.exe app.py
if errorlevel 1 pause
