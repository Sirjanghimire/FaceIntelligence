@echo off
setlocal
cd /d "%~dp0"
call SETUP.bat
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install "pytest>=8.4,<9"
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pytest -q
pause
