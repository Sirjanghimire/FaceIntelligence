"""Bounded model transport for TypeSafe and Groq GPT-OSS."""

import json
import os
import time
from email.utils import parsedate_to_datetime

import httpx

HTTP = httpx.Client(http2=True, timeout=httpx.Timeout(60, connect=10))


def EVENT(record):
    """Replaced by the worker event sink."""
    return None


STATS = {"jev_requests": 0, "groq_requests": 0, "jev_input_tokens": 0, "usage_incomplete": False}
LAST_GROQ = 0.0
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODELS = {"openai/gpt-oss-20b", "openai/gpt-oss-120b"}


def groq_model(name=None):
    name = (name or os.environ.get("TEXT_MODEL", "openai/gpt-oss-120b")).strip()
    if name not in GROQ_MODELS:
        raise ValueError("Choose a supported Groq GPT-OSS model: openai/gpt-oss-20b or openai/gpt-oss-120b.")
    return name


def groq_body(messages, max_tokens=1600):
    return {
        "model": groq_model(),
        "messages": messages,
        "max_completion_tokens": max_tokens,
        "response_format": {"type": "json_object"},
        "stream": False,
    }


def clean_error(value, secret=""):
    text = str(value)
    for key in (
        secret,
        os.environ.get("TYPESAFE_API_KEY", ""),
        os.environ.get("GROQ_API_KEY", ""),
        os.environ.get("OPENROUTER_API_KEY", ""),
    ):
        if key:
            text = text.replace(key, "[REDACTED]")
    return " ".join(text.split())[:800]


def retry_delay(value, attempt):
    if value:
        try:
            delay = float(value)
        except ValueError:
            try:
                delay = parsedate_to_datetime(value).timestamp() - time.time()
            except (ValueError, TypeError, OverflowError):
                delay = 2 ** (attempt + 1)
        if delay > 30:
            raise RuntimeError("Provider requested a longer retry delay. Wait a minute before another run.")
        return max(1, delay)
    return 2 ** (attempt + 1)


def post_json(url, key, body):
    global LAST_GROQ
    if url not in ("https://api.typesafe.ai/v1/systemone", GROQ_URL):
        raise ValueError("Unsupported model endpoint.")
    if not key or not key.strip():
        raise ValueError("Enter your TypeSafe and Groq API keys.")
    is_groq = url == GROQ_URL
    if is_groq:
        groq_model(body.get("model"))
    provider = "Groq" if is_groq else "TypeSafe"
    counter = "groq_requests" if is_groq else "jev_requests"
    for attempt in range(3):
        if STATS[counter] >= (30 if is_groq else 100) or STATS["jev_input_tokens"] >= 200000:
            raise RuntimeError("Run model-call/token limit reached.")
        if is_groq:
            time.sleep(max(0, 3.2 - (time.monotonic() - LAST_GROQ)))
            LAST_GROQ = time.monotonic()
        STATS[counter] += 1
        started = time.perf_counter()
        try:
            response = HTTP.post(url, json=body, headers={"Authorization": "Bearer " + key.strip()})
        except httpx.HTTPError:
            STATS["usage_incomplete"] = True
            raise RuntimeError(f"{provider} connection failed. No ambiguous request was retried.") from None
        if response.status_code in (429, 503, 529) and attempt < 2:
            STATS["usage_incomplete"] = True
            delay = retry_delay(response.headers.get("Retry-After"), attempt)
            EVENT({"event": "retry", "provider": provider, "seconds": round(delay, 1)})
            time.sleep(delay)
            continue
        if response.is_error:
            STATS["usage_incomplete"] = True
            try:
                error = response.json().get("error", {})
                detail = error.get("message", "Request rejected") if isinstance(error, dict) else error
            except ValueError:
                detail = "Request rejected"
            raise RuntimeError(f"{provider} HTTP {response.status_code}: {clean_error(detail, key)}")
        try:
            result = response.json()
        except ValueError:
            STATS["usage_incomplete"] = True
            raise RuntimeError(f"{provider} returned invalid JSON.") from None
        if not isinstance(result, dict) or "error" in result:
            STATS["usage_incomplete"] = True
            raise RuntimeError(f"{provider} returned no usable result.")
        if not is_groq:
            used = result.get("usage", {}).get("input_tokens")
            if type(used) is int and used >= 0:
                STATS["jev_input_tokens"] += used
            else:
                STATS["usage_incomplete"] = True
        EVENT(
            {
                "event": "model_response",
                "provider": provider,
                "model": result.get("model", body.get("model")),
                "latency_ms": round((time.perf_counter() - started) * 1000),
            }
        )
        return result
    raise RuntimeError(f"{provider} retry limit reached.")


def json_completion(system, data):
    result = post_json(
        GROQ_URL,
        os.environ.get("GROQ_API_KEY", ""),
        groq_body(
            [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(data, ensure_ascii=False)}]
        ),
    )
    try:
        content = result["choices"][0]["message"]["content"]
        if not isinstance(content, str) or len(content) > 16000:
            raise ValueError()
        if content.strip().startswith("```"):
            content = content.strip().split("\n", 1)[1].rsplit("```", 1)[0]
        output = json.loads(content)
        if not isinstance(output, dict):
            raise ValueError()
        return output
    except (KeyError, IndexError, TypeError, ValueError):
        raise ValueError("Groq GPT-OSS returned invalid JSON. Try again.") from None
