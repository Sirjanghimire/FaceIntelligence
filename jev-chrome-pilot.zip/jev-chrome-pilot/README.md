# Jev Chrome Pilot 1.0.2

Instruction → Groq GPT-OSS planner → your normal Chrome profile → Jev → final assessment.

This is a separate complete Windows app. It uses the official `browser-harness==0.1.13` package for CDP communication and the jev-ultrafast decision/execution foundation. It does not download or launch a throwaway Chromium browser.

## Start

1. Extract the whole ZIP into a new folder.
2. Double-click **START.bat**. First launch installs dependencies into its own `.venv`. Python 3.12 with the Windows Python launcher is required, as in the earlier apps.
3. Paste your TypeSafe and Groq API keys.
4. Type your complete instruction. Leave Website blank for the planner to choose it.
5. Click **Run instruction**.

Chrome does not need to be running initially. The launcher finds installed Google Chrome and its existing standard User Data directory. When closed, it opens Chrome with its last-used profile, or the existing profile folder you specify. It uses no temporary user-data directory, Guest profile, or incognito mode. When the Chrome debugging endpoint is already available, it attaches without launching another Chrome process.

## Chrome's permission setup

On first setup, the app may open `chrome://inspect/#remote-debugging` in your normal Chrome. Enable **Allow remote debugging for this browser instance**. Accept Chrome's Allow prompt when it appears. The app cannot bypass that permission. Prompts may recur after a browser restart or connection replacement; this is not guaranteed to be a one-time popup.

Chrome opens visibly. Once connected, the app creates a new **tab** for the planned website in the existing browser context. It does not require a tab picker or a pre-opened website.

Your account sessions are available only if that Chrome profile is already logged in and its login has not expired. Logins from Brave do not automatically appear in Chrome. If you have several Chrome profiles, use the profile-folder field (`Default`, `Profile 1`, etc.) shown at the end of Profile Path in `chrome://version`. Before a multi-profile run, verify that the account you intend to use is the one active in Chrome's debugging context. No cookies/passwords are exported or copied.

## Examples

- `Open Wikipedia, search for Computer engineering, and open the article. Leave it visible.`
- `Open Gmail and create a draft to alex@example.com with subject Meeting and body Are you available tomorrow at 3 PM? Do not send it.`

Use real intended recipient details. If you explicitly instruct it to send a fully specified email, the model-driven executor may click Send automatically. There is no per-action approval workflow or separate guaranteed Send lock. A draft request is passed to the models as draft-only.

The planner chooses an HTTP(S) starting website and high-level subgoals. The original instruction remains authoritative; the planner cannot replace it with an unrelated rewritten goal. Missing essential details stop the run with a question before Chrome opens. Jev selects actual controls from the observed page, and a free text model writes field values. A final model assessment checks the final page; it is not a guarantee of real-world success.

## Model costs and privacy

The planner and text helper use Groq's OpenAI-compatible API with `openai/gpt-oss-120b` by default. The model field also accepts `openai/gpt-oss-20b`. Groq usage is subject to your account's rate limits and pricing. Jev uses your TypeSafe credits.

Your task, selected-page visible text/control values, and recent actions go to TypeSafe and/or Groq. This can include visible email content. API keys stay in memory/environment and are not saved by the app. Keys are removed from the environment while starting the Harness daemon so the daemon does not inherit them. Harness recordings and telemetry are disabled for this app.

Local `logs` include task/action text and model evidence. **Copy activity** may contain private task text; inspect it before sharing. Diagnostic records omit page and protocol payloads. Browser Harness also keeps its own local runtime diagnostics in its normal application config directory.

## Stop and completion

On completion, the app detaches its page session and leaves Chrome/the result tab open. Browser Harness retains its approved connection for reuse. It does not independently plan or execute further tasks.

Stop terminates the task worker, not Chrome or the Harness daemon. Already-issued browser commands may finish; completed actions are not undone. Closing the app also stops the worker. To revoke debugging access entirely, disable remote debugging in Chrome.

Each run opens one new tab. The app does not reuse arbitrary personal tabs or close your other tabs.

## Troubleshooting

- **No existing Chrome profile:** Open ordinary Google Chrome and sign into the intended account once. The app deliberately does not make a substitute blank profile.
- **Profile picker / wrong account:** Set the correct existing profile folder in the app. Blank means Chrome's last-used profile.
- **Debugging setup waiting:** Enable the checkbox on Chrome's inspect page. Up to two minutes are allowed for setup. This is a timeout, not a mandatory wait.
- **Browser Harness connection waiting:** Accept Chrome's Allow prompt. Keep the current run active while approving; repeatedly restarting can recreate the request.
- **Invalid/missing plan:** Add the missing information to your instruction or specify the optional website.
- **401/402/429:** Check the Groq API key, TypeSafe credits, and provider account limits. Connection itself uses no model tokens; the initial plan is a Groq call.
- **No supported control / uncertain outcome:** This is a DOM agent; some complex pages need additional support. Inspect the browser result and activity log.

## Limits

Visible HTML controls, typing including contenteditable editors, native dropdowns and page scrolling within one tab. No automatic popup switching, iframe/shadow-root traversal, file upload workflows, or guaranteed nested-container scrolling. Browser UI dialogs and authentication challenges require the user. Page instructions are treated as untrusted in model prompts but model mistakes remain possible.

No Windows Chrome/Gmail end-to-end run was possible in the development environment. See VALIDATION.md for exact checks. The previous Brave app's successful connection does not prove this edition's Chrome cold start or Gmail execution.

## Earlier planner correction

The initial planner previously could guess that login was required and stop before opening Chrome. Its instructions now explicitly mark authentication as unobserved and restrict pre-browser clarification to missing task details. Fully specified tasks should proceed to the actual page. This is a prompt correction, not a guarantee that GPT-OSS follows it; browser/login behavior still needs live verification.

## 1.0.2 typing-loop repair

Extract this entire ZIP into a new folder and run START.bat. Keep using your TypeSafe and Groq keys. The included executor is updated consistently with the Groq files supplied separately from the older ZIP.

- Covered controls are excluded from the action snapshot using the same center-point hit test as execution. This prevents repeated selection of fields behind autocomplete overlays.
- Filling uses observed target identity and scoped guards before text generation and immediately before input, as click/select already did. Unrelated global visible-text changes no longer invalidate an unchanged field. Navigation, field values, scope changes, disabled/readonly status and occlusion still have checks.
- The executor checks that the clicked field actually holds focus before selecting and replacing text.
- Six consecutive stale/covered rejections stop the run with the reason. Each rejection produces an action_retry log entry. An executed action resets the counter.
- The existing 200,000-input-token stop remains unchanged. It is checked between model calls, so the last response can take the total above that threshold.

The original log did not record rejection reasons, so it cannot prove which guard failed on Gmail. These changes address the identified retry-loop defects, but are not a claim of a verified Gmail send. First test with a draft-only instruction, then inspect its recipient, subject and body.
