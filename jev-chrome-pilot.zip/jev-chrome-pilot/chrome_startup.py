"""Open installed Chrome with its existing profile, then locate that browser's CDP metadata."""

import hashlib
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path

import diagnostics


def chrome_root():
    if os.name != "nt":
        raise RuntimeError("This launcher targets Windows Chrome.")
    return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Google/Chrome/User Data"


def chrome_binary():
    bases = [os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("LOCALAPPDATA")]
    for base in bases:
        if base:
            p = Path(base) / "Google/Chrome/Application/chrome.exe"
            if p.is_file():
                return p
    raise RuntimeError("Google Chrome was not found. Install normal Google Chrome before using this app.")


def choose_profile(root, requested=""):
    try:
        state = json.loads((root / "Local State").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise RuntimeError("No existing Chrome profile found. Open normal Chrome and sign in once first.") from exc
    profile = requested.strip() or state.get("profile", {}).get("last_used", "Default")
    if not re.fullmatch(r"Default|Profile [0-9]+", profile) or not (root / profile).is_dir():
        raise ValueError("Use an existing Chrome profile folder name: Default or Profile 1, for example.")
    return profile


def live_endpoint(root):
    try:
        lines = (root / "DevToolsActivePort").read_text(encoding="utf-8").splitlines()
        port = int(lines[0])
        path = lines[1].strip()
        if not 1 <= port <= 65535 or not re.fullmatch(r"/devtools/browser/[A-Za-z0-9-]+", path):
            return None
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            pass
        return f"ws://127.0.0.1:{port}{path}"
    except (OSError, ValueError, IndexError):
        return None


def prepare_chrome(profile=""):
    root = chrome_root()
    selected = choose_profile(root, profile)
    endpoint = live_endpoint(root)
    if endpoint:
        diagnostics.emit("chrome", "already_running", profile=selected)
        return endpoint
    binary = chrome_binary()
    diagnostics.emit("chrome", "opening_normal_profile", profile=selected)
    # No user-data-dir, guest, incognito, or temporary profile. Chrome either
    # cold-starts normally or forwards this URL to the already-running instance.
    subprocess.Popen(
        [str(binary), f"--profile-directory={selected}", "chrome://inspect/#remote-debugging"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    with diagnostics.stage("chrome_debugging_setup", profile=selected, timeout_s=120):
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            endpoint = live_endpoint(root)
            if endpoint:
                return endpoint
            time.sleep(0.5)
    raise RuntimeError(
        "In your normal Chrome profile, enable Allow remote debugging for this browser instance "
        "at chrome://inspect/#remote-debugging, then click Run again."
    )


def connect_harness(profile=""):
    endpoint = prepare_chrome(profile)
    # A dedicated daemon per actual Chrome instance avoids attaching to Brave
    # or to a previous Chrome process. This is not a browser profile directory.
    os.environ["BU_NAME"] = "jev-chrome-" + hashlib.sha256(endpoint.encode()).hexdigest()[:12]
    os.environ["BU_CDP_WS"] = endpoint
    os.environ.pop("BU_CDP_URL", None)
    os.environ.pop("BU_BROWSER_ID", None)
    os.environ["BH_RECORD"] = "0"
    os.environ["BH_TELEMETRY"] = "0"
    os.environ["BH_UPDATE_CHECK"] = "0"
    # Delay imports until the daemon name and Chrome endpoint have been set.
    from browser_harness.admin import ensure_daemon
    from browser_harness.helpers import cdp

    secrets = {
        key: os.environ.pop(key)
        for key in ("TYPESAFE_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY")
        if key in os.environ
    }
    try:
        with diagnostics.stage("browser_harness_connection"):
            ensure_daemon(wait=120, env={"BU_CDP_WS": endpoint})
    finally:
        os.environ.update(secrets)
    return cdp
