from unittest.mock import Mock

import httpx
import pytest

import planner
import services
import worker

PLAN = {"steps": ["Find the guide", "Open it"], "success_criteria": ["The guide is open"], "needs_input": None}
PAGE = {"url": "https://example.org/guide", "title": "Guide", "text": "Guide opened", "actions": []}


@pytest.fixture(autouse=True)
def reset_services(monkeypatch):
    monkeypatch.setattr(
        services,
        "STATS",
        {"jev_requests": 0, "groq_requests": 0, "jev_input_tokens": 0, "usage_incomplete": False},
    )
    monkeypatch.setattr(services, "LAST_GROQ", 0)
    monkeypatch.setattr(services, "EVENT", Mock())
    monkeypatch.setattr(services.time, "sleep", Mock())
    monkeypatch.delenv("TEXT_MODEL", raising=False)
    monkeypatch.setenv("GROQ_API_KEY", "test-groq-key")


@pytest.mark.parametrize("model", ["openrouter/auto", "openai/gpt-4o", "inception/mercury-2.5"])
def test_unsupported_models_rejected_before_request(model):
    with pytest.raises(ValueError, match="supported Groq"):
        services.groq_model(model)


def test_groq_json_mode_and_token_parameter(monkeypatch):
    post = Mock(return_value=httpx.Response(200, json={"model": "routed-free-model", "choices": []}))
    monkeypatch.setattr(services.HTTP, "post", post)
    body = services.groq_body([{"role": "user", "content": "Return JSON"}])
    services.post_json("https://api.groq.com/openai/v1/chat/completions", "test", body)
    sent = post.call_args.kwargs["json"]
    assert sent["model"] == "openai/gpt-oss-120b"
    assert sent["max_completion_tokens"] == 1600
    assert sent["response_format"] == {"type": "json_object"}
    assert "models" not in sent


def test_rate_limit_then_success_is_bounded(monkeypatch):
    post = Mock(
        side_effect=[
            httpx.Response(429, headers={"Retry-After": "2"}),
            httpx.Response(200, json={"usage": {"input_tokens": 42}}),
        ]
    )
    monkeypatch.setattr(services.HTTP, "post", post)
    services.post_json("https://api.typesafe.ai/v1/systemone", "test", {})
    assert post.call_count == 2
    assert services.STATS["jev_input_tokens"] == 42
    assert services.STATS["usage_incomplete"]


def test_ambiguous_network_error_not_retried(monkeypatch):
    post = Mock(side_effect=httpx.ReadTimeout("lost response"))
    monkeypatch.setattr(services.HTTP, "post", post)
    with pytest.raises(RuntimeError, match="No ambiguous request"):
        services.post_json("https://api.typesafe.ai/v1/systemone", "test", {})
    assert post.call_count == 1


def test_provider_error_redacts_key(monkeypatch):
    monkeypatch.setattr(
        services.HTTP,
        "post",
        Mock(return_value=httpx.Response(401, json={"error": {"message": "Invalid test-groq-key"}})),
    )
    with pytest.raises(RuntimeError) as exc:
        services.post_json(
            "https://api.groq.com/openai/v1/chat/completions", "test-groq-key", services.groq_body([])
        )
    assert "test-groq-key" not in str(exc.value)
    assert "[REDACTED]" in str(exc.value)


def test_long_retry_after_stops_instead_of_retrying_early(monkeypatch):
    post = Mock(return_value=httpx.Response(429, headers={"Retry-After": "120"}))
    monkeypatch.setattr(services.HTTP, "post", post)
    with pytest.raises(RuntimeError, match="longer retry"):
        services.post_json("https://api.typesafe.ai/v1/systemone", "test", {})
    assert post.call_count == 1


@pytest.mark.parametrize(
    "plan",
    [
        {},
        {"steps": [], "success_criteria": ["ok"], "needs_input": None},
        {"steps": ["x"], "success_criteria": ["x"], "needs_input": False},
    ],
)
def test_malformed_plans_stop(plan):
    with pytest.raises(ValueError):
        planner.validate_plan(plan)


def test_planner_receives_original_goal_and_date(monkeypatch):
    completion = Mock(return_value=PLAN)
    monkeypatch.setattr(planner, "json_completion", completion)
    assert planner.make_plan("Find the guide", PAGE, "2026-09-26") == PLAN
    sent = completion.call_args.args[1]
    assert sent["user_goal"] == "Find the guide" and sent["current_date"] == "2026-09-26"


def test_fabricated_verification_evidence_rejected(monkeypatch):
    monkeypatch.setattr(
        planner,
        "json_completion",
        Mock(return_value={"satisfied": True, "evidence": ["Not present on page"], "reason": "Looks done"}),
    )
    assert not planner.assess("Open guide", PAGE, ["guide open"])["satisfied"]


def test_verification_requires_real_boolean(monkeypatch):
    monkeypatch.setattr(
        planner, "json_completion", Mock(return_value={"satisfied": "false", "evidence": [], "reason": "No"})
    )
    with pytest.raises(ValueError):
        planner.assess("Open guide", PAGE, [])


def test_missing_input_prevents_browser_actions(monkeypatch):
    agent = Mock()
    agent.state = {"page": PAGE}
    monkeypatch.setattr(worker, "make_plan", Mock(return_value={**PLAN, "needs_input": "Which city?"}))
    emit = Mock()
    worker.execute_plan(agent, {"goal": "Find a hotel"}, emit)
    agent.command.assert_not_called()
    assert emit.call_args.args[0]["status"] == "needs_input"


def test_done_without_expected_text_is_not_success(monkeypatch):
    agent = Mock()
    agent.state = {"page": PAGE, "status": "done"}
    agent.browser.observe.return_value = PAGE
    monkeypatch.setattr(worker, "make_plan", Mock(return_value=PLAN))
    check = Mock()
    monkeypatch.setattr(worker, "assess", check)
    emit = Mock()
    worker.execute_plan(agent, {"goal": "Open guide", "expect": "Missing condition"}, emit)
    assert emit.call_args.args[0]["status"] == "verification_failed"
    check.assert_not_called()


@pytest.mark.parametrize("url", ["javascript:alert(1)", "file:///etc/passwd", "https://a:b@example.org"])
def test_custom_url_validation(url):
    with pytest.raises(ValueError):
        worker.validate_config({"goal": "test", "url": url, "target_id": "test-tab"})


def test_parse_json_without_executing_code(monkeypatch):
    monkeypatch.setattr(
        services, "post_json", Mock(return_value={"choices": [{"message": {"content": '```json\n{"steps":[]}\n```'}}]})
    )
    assert services.json_completion("test", {}) == {"steps": []}
