import json
from unittest.mock import Mock

import pytest

import chrome_startup
import planner
from jev_ultrafast import transport


@pytest.fixture
def profile(tmp_path):
    (tmp_path / "Profile 2").mkdir()
    (tmp_path / "Default").mkdir()
    (tmp_path / "Local State").write_text(json.dumps({"profile": {"last_used": "Profile 2"}}))
    return tmp_path


def test_existing_profile_selected_without_creating_new_one(profile):
    assert chrome_startup.choose_profile(profile) == "Profile 2"
    assert chrome_startup.choose_profile(profile, "Default") == "Default"
    with pytest.raises(ValueError):
        chrome_startup.choose_profile(profile, "../../other")
    with pytest.raises(ValueError):
        chrome_startup.choose_profile(profile, "Profile 99")


def test_cold_start_uses_normal_chrome_no_temporary_profile(monkeypatch, profile):
    monkeypatch.setattr(chrome_startup, "chrome_root", lambda: profile)
    monkeypatch.setattr(chrome_startup, "chrome_binary", lambda: "chrome.exe")
    monkeypatch.setattr(
        chrome_startup, "live_endpoint", Mock(side_effect=[None, "ws://127.0.0.1:9222/devtools/browser/a"])
    )
    launch = Mock()
    monkeypatch.setattr(chrome_startup.subprocess, "Popen", launch)
    chrome_startup.prepare_chrome()
    args = launch.call_args.args[0]
    assert args == ["chrome.exe", "--profile-directory=Profile 2", "chrome://inspect/#remote-debugging"]
    assert not any("--user-data-dir" in a or "--incognito" in a or "--guest" in a for a in args)


def test_warm_start_does_not_launch_another_chrome(monkeypatch, profile):
    monkeypatch.setattr(chrome_startup, "chrome_root", lambda: profile)
    monkeypatch.setattr(chrome_startup, "live_endpoint", lambda root: "ws://127.0.0.1:9222/devtools/browser/a")
    launch = Mock()
    monkeypatch.setattr(chrome_startup.subprocess, "Popen", launch)
    assert chrome_startup.prepare_chrome().startswith("ws://")
    launch.assert_not_called()


@pytest.mark.parametrize("url", ["file:///private", "javascript:alert(1)", "https://user:pass@example.com", ""])
def test_invalid_planned_urls_cannot_open_browser(monkeypatch, url):
    monkeypatch.setattr(
        planner,
        "json_completion",
        lambda *a: {"url": url, "steps": ["Open site"], "success_criteria": ["Done"], "needs_input": None},
    )
    with pytest.raises(ValueError):
        planner.route_task("Open a website")


def test_original_instruction_and_url_override_are_preserved(monkeypatch):
    completion = Mock(
        return_value={
            "url": "https://other.example",
            "steps": ["Create draft"],
            "success_criteria": ["Draft exists"],
            "needs_input": None,
        }
    )
    monkeypatch.setattr(planner, "json_completion", completion)
    instruction = "Draft an email. Do not send it."
    result = planner.route_task(instruction, "https://mail.google.com/")
    assert result["url"] == "https://mail.google.com/"
    assert completion.call_args.args[1]["instruction"] == instruction


def test_ambiguous_instruction_can_request_input_before_browser(monkeypatch):
    monkeypatch.setattr(
        planner,
        "json_completion",
        lambda *a: {
            "url": "",
            "steps": ["Obtain recipient"],
            "success_criteria": ["Recipient known"],
            "needs_input": "What is the recipient email address?",
        },
    )
    assert planner.route_task("Send Bob a message")["plan"]["needs_input"]


def test_harness_creates_only_a_tab_and_detaches_without_closing_browser(monkeypatch):
    calls = []

    def cdp(method, **kwargs):
        calls.append((method, kwargs))
        if method == "Target.createTarget":
            return {"targetId": "new"}
        if method == "Target.attachToTarget":
            return {"sessionId": "session"}
        return {}

    monkeypatch.setattr(transport, "connect_harness", lambda p: cdp)
    b = transport.BrowserTransport()
    b.close()
    assert calls[0] == ("Target.createTarget", {"url": "about:blank", "_response_timeout": 30})
    assert calls[-1][0] == "Target.detachFromTarget"
    assert not any(
        method in ("Browser.close", "Target.createBrowserContext", "Target.closeTarget") for method, _ in calls
    )
