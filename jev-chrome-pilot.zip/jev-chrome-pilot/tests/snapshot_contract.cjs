// Minimal DOM fixture: exercises the real snapshot script, not browser layout.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../jev_ultrafast/snapshot.js'), 'utf8');
const field = {
  type: 'text', tagName: 'INPUT', value: '', checked: false, disabled: false, readOnly: false,
  isConnected: true, labels: [], childNodes: [], parentElement: {innerText: 'Compose'},
  getAttribute: k => k === 'aria-label' ? 'Subject' : null,
  closest: () => null, matches: () => false, checkVisibility: () => true,
  getBoundingClientRect: () => ({x: 10, y: 10, width: 200, height: 30}),
  contains: e => e === field,
};
let covering = null;
const document = {
  body: {}, title: 'Compose', documentElement: {scrollHeight: 600},
  querySelectorAll: () => [field], getElementById: () => null,
  elementFromPoint: () => covering || field,
  createTreeWalker: () => ({nextNode: () => null}), createRange: () => ({}),
};
const context = vm.createContext({window: {}, document, performance: {timeOrigin: 1},
  location: {href: 'https://example.test/'}, scrollX: 0, scrollY: 0,
  innerWidth: 800, innerHeight: 600, NodeFilter: {SHOW_TEXT: 4}});
let snapshot = vm.runInContext(source, context);
assert.equal(snapshot.actions.filter(a => a.kind === 'fill').length, 1);
covering = {}; // Suggestion overlay covers the field center.
snapshot = vm.runInContext(source, context);
assert.equal(snapshot.actions.filter(a => a.kind === 'fill').length, 0);
covering = null;
snapshot = vm.runInContext(source, context);
assert.equal(snapshot.actions.filter(a => a.kind === 'fill').length, 1);
console.log('Snapshot fixture passed: exposed / covered / exposed field.');
