# Validation — Chrome Pilot 1.0.2

- 70 Python offline tests passed on Python 3.12. Browser protocol and model calls are mocked.
- Regression coverage includes action-scoped fill validation, missing guards, bounded stale retries, recovery/reset after execution, and stopping before typing when focus is lost.
- Existing planner, provider, original-goal preservation, Chrome profile, native input, and no-duplicate-retry contracts remain tested. Provider tests and field generation now consistently use Groq.
- The actual snapshot JavaScript passed a minimal mocked-DOM fixture covering an exposed field, a field covered by an overlay, and the field becoming exposed again. This does not verify browser layout. Optional reproduction: node tests/snapshot_contract.cjs.
- Python compilation and JavaScript syntax checks passed.
- No paid API requests or emails were sent. No Windows Chrome/Gmail end-to-end verification was possible. A Playwright Chromium download was attempted but failed; no live-browser test success is claimed.

Run TEST.bat for the Python tests. Node is not required to run the app.
